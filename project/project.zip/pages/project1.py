import streamlit as st
from utils import project1_desc as p1d


def app():
	st.write('''
		### 공통 프로 젝트 
		'''
		)
	
	p1d.desc()
